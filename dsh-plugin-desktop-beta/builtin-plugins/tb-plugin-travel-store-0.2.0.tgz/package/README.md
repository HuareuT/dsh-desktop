# tb-plugin-travel-store

Travel Buddy App Center — the only C-end plugin channel (option A).

- Lists only plugins the cloud granted to the logged-in user (`/api/verify` →
  `plugins[]`, filtered against the private catalog page returned by the
  Host's market API).
- One-click install through the official market operations API
  (`/api/community-market/operations/preview` → `execute`), the exact path the
  stock market UI uses.
- After a successful install, prompts the user to restart the app
  (`application === 'restart-required'`).
- Fail-closed: no valid session, no panel.
