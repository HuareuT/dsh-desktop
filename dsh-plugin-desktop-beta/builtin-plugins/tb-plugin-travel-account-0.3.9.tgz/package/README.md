# dsh-price-compare

Travel Buddy vertical-plugin PoC (T11): a plugin "published by the backend" that,
once installed, adds a **一键比价** entry under 自动化任务 in the DSH sidebar and
renders a page whose button calls a cloud API (`GET /api/price-compare`).

- Host side (`lib/index.js`): no-op for the PoC.
- Client side (`lib/client.js`): registers `sidebar.panellist` (order 11, right
  below 自动化任务's order 10) and a `main` panel keyed `price-compare`.

Build: `npm install && npm run build` · Package: `npm pack`
