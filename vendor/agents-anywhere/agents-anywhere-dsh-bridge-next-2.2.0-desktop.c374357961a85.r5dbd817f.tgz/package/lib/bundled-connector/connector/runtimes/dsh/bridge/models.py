from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from typing import Any, cast

from connector.core.unicode import replace_lone_surrogates
from connector.runtime_protocol import (
    RuntimeCapability,
    RuntimeCapabilitySet,
    RuntimeCommand,
    RuntimeCommandResult,
    RuntimeModelCatalog,
    RuntimeModelGroup,
    RuntimeModelItem,
    RuntimePermissionCatalog,
    RuntimePermissionItem,
    RuntimeReasoningItem,
    RuntimeTimelineItem,
    SessionMeta,
    SessionNotice,
    SessionState,
    timeline_content_hash,
)
from connector.runtime_protocol.models import RuntimeStatus

_STATUSES = {
    "idle",
    "waiting",
    "pending",
    "running",
    "stopping",
    "waiting_approval",
    "blocked",
    "error",
    "disconnected",
}


COMMAND_BRIDGE_UPGRADE_REASON = "Upgrade the DSH Bridge to enable native session commands."


def capability_set(value: Any, *, connector_id: str) -> RuntimeCapabilitySet:
    data = _mapping(value, "capability set")
    runtime = _runtime(data)
    session_id = _optional_string(data.get("sessionId"))
    capabilities: list[RuntimeCapability] = []
    for raw in _list(data.get("capabilities"), "capabilities"):
        item = _mapping(raw, "capability")
        if item.get("capabilityId") == "session.commands":
            # Command support requires negotiated facts, not the name alone.
            for flag in ("supported", "available", "allowed"):
                item.setdefault(flag, False)
            if not item["supported"] and not _dict(item.get("metadata")).get("catalogRevision"):
                item["unavailableReason"] = COMMAND_BRIDGE_UPGRADE_REASON
        scope = item.get("scope", "session" if session_id else "runtime")
        if scope not in {"runtime", "session"}:
            raise ValueError("DSH capability scope is invalid")
        capabilities.append(
            RuntimeCapability(
                capability_id=_required_string(
                    item.get("capabilityId"), "capabilityId"
                ),
                scope=scope,
                runtime=runtime,
                version=str(item.get("version") or "1"),
                session_id=_optional_string(item.get("sessionId")) or session_id,
                connector_id=connector_id,
                supported=_boolean(item.get("supported"), True),
                available=_boolean(item.get("available"), True),
                allowed=_boolean(item.get("allowed"), True),
                unavailable_reason=_optional_string(item.get("unavailableReason")),
                metadata=_dict(item.get("metadata")),
            )
        )
    if not any(capability.capability_id == "session.commands" for capability in capabilities):
        capabilities.append(RuntimeCapability(
            capability_id="session.commands", scope="session" if session_id else "runtime", runtime=runtime,
            session_id=session_id, connector_id=connector_id, supported=False, available=False, allowed=False,
            unavailable_reason=COMMAND_BRIDGE_UPGRADE_REASON,
        ))
    return RuntimeCapabilitySet(
        runtime=runtime,
        revision=_revision(data.get("revision")),
        capabilities=tuple(capabilities),
        session_id=session_id,
        connector_id=connector_id,
        metadata=_dict(data.get("metadata")),
    )


def model_catalog(value: Any) -> RuntimeModelCatalog:
    data = _mapping(value, "model catalog")
    models: list[RuntimeModelItem] = []
    for raw in _list(data.get("models"), "models"):
        item = _mapping(raw, "model")
        reasoning: list[RuntimeReasoningItem] = []
        for raw_effort in _list(item.get("reasoningItems", []), "reasoningItems"):
            effort = _mapping(raw_effort, "reasoning item")
            reasoning.append(
                RuntimeReasoningItem(
                    id=_required_string(effort.get("id"), "reasoning id"),
                    title=_required_string(effort.get("title"), "reasoning title"),
                    selection_id=_required_string(
                        effort.get("selectionId"), "reasoning selectionId"
                    ),
                    description=_optional_string(effort.get("description")),
                    enabled=_boolean(effort.get("enabled"), True),
                    disabled_reason=_optional_string(effort.get("disabledReason")),
                    metadata=_dict(effort.get("metadata")),
                )
            )
        models.append(
            RuntimeModelItem(
                id=_required_string(item.get("id"), "model id"),
                title=_required_string(item.get("title"), "model title"),
                selection_id=_optional_string(item.get("selectionId")),
                description=_optional_string(item.get("description")),
                reasoning_items=tuple(reasoning),
                enabled=_boolean(item.get("enabled"), True),
                disabled_reason=_optional_string(item.get("disabledReason")),
                metadata=_dict(item.get("metadata")),
            )
        )
    return RuntimeModelCatalog(
        runtime=_runtime(data),
        revision=_revision(data.get("revision")),
        models=_grouped_by_provider(models),
    )


def _grouped_by_provider(models: list[RuntimeModelItem]) -> tuple[RuntimeModelItem, ...]:
    """Group each model under the DSH provider (channel or relay) that routes it.

    Every Bridge since configuration support reports ``provider`` and
    ``providerName`` in model metadata. Two providers sharing a display name
    keep their IDs visible, matching the Bridge's model title rule. Under a
    group header the row drops the provider the Bridge appends to colliding
    names; two IDs sharing a name inside one provider keep their ``[model]``.
    """

    names: dict[str, str] = {}
    for model in models:
        provider = _optional_string(model.metadata.get("provider"))
        if provider and provider not in names:
            names[provider] = _optional_string(model.metadata.get("providerName")) or provider
    shared = {name for name in names.values() if list(names.values()).count(name) > 1}

    def item_title(model: RuntimeModelItem, provider: str) -> str | None:
        name = _optional_string(model.metadata.get("modelName"))
        if name is None:
            return None
        model_id = model.metadata.get("model")
        twins = any(
            other.metadata.get("provider") == provider and other.metadata.get("modelName") == name
            and other.metadata.get("model") != model_id
            for other in models
        )
        return f"{name} [{model_id}]" if twins else name

    return tuple(
        replace(model, group=RuntimeModelGroup(
            id=provider,
            title=f"{names[provider]} / {provider}" if names[provider] in shared else names[provider],
            item_title=item_title(model, provider),
        ))
        if (provider := _optional_string(model.metadata.get("provider")))
        else model
        for model in models
    )


def permission_catalog(value: Any) -> RuntimePermissionCatalog:
    data = _mapping(value, "permission catalog")
    permissions: list[RuntimePermissionItem] = []
    for raw in _list(data.get("permissions"), "permissions"):
        item = _mapping(raw, "permission")
        permissions.append(
            RuntimePermissionItem(
                id=_required_string(item.get("id"), "permission id"),
                title=_required_string(item.get("title"), "permission title"),
                selection_id=_required_string(
                    item.get("selectionId"), "permission selectionId"
                ),
                description=_optional_string(item.get("description")),
                enabled=_boolean(item.get("enabled"), True),
                disabled_reason=_optional_string(item.get("disabledReason")),
                metadata=_dict(item.get("metadata")),
            )
        )
    return RuntimePermissionCatalog(
        runtime=_runtime(data),
        revision=_revision(data.get("revision")),
        permissions=tuple(permissions),
    )


def session_meta(value: Any, *, session_id: str | None = None) -> SessionMeta:
    data = _mapping(value, "session meta")
    return SessionMeta(
        session_id=session_id or _required_string(data.get("sessionId"), "sessionId"),
        external_session_id=_required_string(
            data.get("externalSessionId"), "externalSessionId"
        ),
        runtime=_runtime(data),
        title=_optional_string(data.get("title")),
        cwd=_optional_string(data.get("cwd")),
        ordering_time=_optional_string(
            data.get("orderingTime") or data.get("lastActivityAt")
        ),
        metadata=_dict(data.get("metadata")),
    )


def session_state(value: Any) -> SessionState:
    data = _mapping(value, "session state")
    raw_status = data.get("status")
    if raw_status not in _STATUSES:
        raise ValueError("DSH session status is invalid")
    selections = {
        str(key): item if isinstance(item, str) else None
        for key, item in _dict(data.get("selections")).items()
        if isinstance(key, str) and (item is None or isinstance(item, str))
    }
    return SessionState(
        session_id=_required_string(data.get("sessionId"), "sessionId"),
        external_session_id=_optional_string(data.get("externalSessionId")),
        runtime=_runtime(data),
        status=cast(RuntimeStatus, raw_status),
        selections=selections,
        status_reason=_optional_string(data.get("statusReason")),
        error=_dict(data.get("error"))
        if isinstance(data.get("error"), Mapping)
        else None,
        metadata=_dict(data.get("metadata")),
    )


def timeline_item(
    value: Any, *, default_session_id: str | None = None
) -> RuntimeTimelineItem:
    """Decode canonical platform items; native DSH projection belongs to the plugin."""
    data = _mapping(value, "timeline item")
    if "payload" in data:
        raise ValueError("DSH native payload projection is no longer supported")
    item_type = _required_string(data.get("type"), "timeline type")
    status = _required_string(data.get("status"), "timeline status")
    role = _optional_string(data.get("role"))
    if item_type not in {
        "message",
        "tool",
        "artifact",
        "marker",
        "system",
        "turn.start",
        "turn.end",
    }:
        raise ValueError("DSH timeline type is invalid")
    if status not in {
        "pending",
        "inProgress",
        "running",
        "waiting_approval",
        "done",
        "failed",
        "cancelled",
        "interrupted",
        "hidden",
    }:
        raise ValueError("DSH timeline status is invalid")
    if role not in {None, "user", "assistant", "system", "tool"}:
        raise ValueError("DSH timeline role is invalid")
    content = _mapping(data.get("content"), "timeline content")
    computed_hash = timeline_content_hash(item_type, status, role, content)  # type: ignore[arg-type]
    if data.get("contentHash") != computed_hash:
        raise ValueError("DSH timeline contentHash does not match canonical content")
    # Plugins since 2.1.0 normalize lone surrogates before hashing; older ones
    # hash the raw text. The hash is checked above either way; what gets
    # stored and forwarded must be encodable.
    content = replace_lone_surrogates(content)
    return RuntimeTimelineItem(
        id=_required_string(data.get("id"), "timeline id"),
        session_id=default_session_id
        or _required_string(data.get("sessionId"), "sessionId"),
        type=item_type,
        status=status,
        order_seq=_nonnegative_int(data.get("orderSeq"), "orderSeq"),
        content_hash=computed_hash,
        role=role,
        turn_id=_optional_string(data.get("turnId")),
        content=content,
        source=replace_lone_surrogates(_mapping(data.get("source"), "timeline source")),
        revision=max(1, _nonnegative_int(data.get("revision"), "revision")),
        metadata=replace_lone_surrogates(_dict(data.get("metadata"))),
    )


def notice(value: Any) -> SessionNotice:
    data = _mapping(value, "notice")
    notice_type = data.get("type", "notification")
    if notice_type not in {"notification", "interaction"}:
        raise ValueError("DSH notice type is invalid")
    severity = data.get("severity", "info")
    if severity not in {"info", "success", "warning", "error"}:
        raise ValueError("DSH notice severity is invalid")
    return SessionNotice(
        notice_id=_required_string(data.get("noticeId"), "noticeId"),
        session_id=_required_string(data.get("sessionId"), "sessionId"),
        runtime=_runtime(data),
        type=notice_type,
        title=_required_string(data.get("title"), "notice title"),
        message=_optional_string(data.get("message")),
        severity=severity,
        status=_optional_string(data.get("status")) or "open",
        interaction_type=_optional_string(data.get("interactionType")),
        blocking=_dict(data.get("blocking"))
        if isinstance(data.get("blocking"), Mapping)
        else None,
        response_required=_boolean(data.get("responseRequired"), False),
        actions=tuple(
            _dict(item) for item in _list(data.get("actions", []), "actions")
        ),
        source=_dict(data.get("source")),
        context=_dict(data.get("context")),
        metadata=_dict(data.get("metadata")),
    )


def commands(value: Any) -> tuple[RuntimeCommand, ...]:
    raw_items = value.get("commands") if isinstance(value, Mapping) else value
    output: list[RuntimeCommand] = []
    for raw in _list(raw_items, "commands"):
        item = _mapping(raw, "command")
        output.append(
            RuntimeCommand(
                id=_required_string(item.get("id") or item.get("name"), "command id"),
                title=_required_string(
                    item.get("title") or item.get("name"), "command title"
                ),
                description=_optional_string(item.get("description")),
                aliases=tuple(
                    value for value in item.get("aliases", []) if isinstance(value, str)
                ),
                category=_optional_string(item.get("category")),
                scope="session",
                enabled=_boolean(item.get("enabled"), True),
                disabled_reason=_optional_string(item.get("disabledReason")),
                accepts_args=_boolean(item.get("acceptsArgs"), False),
                args_schema=_dict(item.get("argsSchema"))
                if isinstance(item.get("argsSchema"), Mapping)
                else None,
                metadata=_dict(item.get("metadata")),
            )
        )
    return tuple(output)


def command_result(value: Any, command: str) -> RuntimeCommandResult:
    data = _mapping(value, "command result")
    returned_command = _required_string(data.get("command"), "command identity")
    if returned_command != command:
        raise ValueError("DSH returned a different command identity")
    ok = data.get("ok")
    if not isinstance(ok, bool):
        # Wire decode failures consistently use ValueError.
        raise ValueError("DSH command acknowledgement must include a boolean ok")  # noqa: TRY004
    result = _mapping(data.get("result"), "command result details")
    kind = result.get("kind")
    if "kind" in result and (
        not isinstance(kind, str) or kind not in {"success", "error"}
    ):
        raise ValueError("DSH command result kind is invalid")
    command_id = result.get("commandId")
    if "commandId" in result:
        _required_string(command_id, "command ID")
    if "text" in result and not isinstance(result["text"], str):
        raise ValueError("DSH command result text is invalid")
    if "sourceEventSeq" in result:
        _nonnegative_int(result["sourceEventSeq"], "source event sequence")
        if kind != "success":
            raise ValueError("Only a successful DSH command can have a source event")
    state = result.get("executionState")
    if "executionState" in result and (
        not isinstance(state, str)
        or state not in {"accepted", "completed", "unknown"}
    ):
        raise ValueError("DSH command execution state is invalid")
    if "retryable" in result and (
        result["retryable"] is not False or state != "unknown"
    ):
        raise ValueError("An uncertain DSH command may not be retried automatically")
    if ok:
        if (
            kind != "success"
            or command_id is None
            or state != "accepted"
            or "retryable" in result
            or "code" in data
        ):
            raise ValueError("DSH successful command acknowledgement is incomplete or inconsistent")
    elif (
        kind == "success"
        or kind == "error" and (command_id is None or state != "completed")
        or kind is None and (command_id is not None or state not in {None, "unknown"})
    ):
        raise ValueError("DSH failed command acknowledgement is inconsistent")
    code = data.get("code")
    if not ok:
        _required_string(code, "command failure code")
        if kind == "error" and code != "command_error":
            raise ValueError("DSH native command error has an inconsistent failure code")
        if kind is None and code == "command_error":
            raise ValueError("DSH native command error is missing its result identity")
        if code in {"command_failed", "command_outcome_unknown"}:
            if kind is not None or state != "unknown" or result.get("retryable") is not False:
                raise ValueError("DSH unknown command outcome has incomplete no-retry details")
        elif kind is None and (
            code not in {
                "invalid_command", "command_attachments_unsupported", "unknown_command"
            }
            or state is not None
            or "retryable" in result
        ):
            raise ValueError("DSH pre-dispatch validation has inconsistent execution details")
    elif code is not None:
        raise ValueError("DSH successful command acknowledgement has an error code")
    if "message" in data and not isinstance(data["message"], str):
        raise ValueError("DSH command message is invalid")
    return RuntimeCommandResult(
        command=returned_command,
        ok=ok,
        code=code,
        message=_optional_string(data.get("message")),
        result=result,
    )


def _runtime(data: Mapping[str, Any]) -> str:
    runtime = data.get("runtime", "dsh")
    if runtime != "dsh":
        raise ValueError("bridge payload runtime must be dsh")
    return "dsh"


def _mapping(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"DSH {label} must be an object")
    return {str(key): item for key, item in value.items() if isinstance(key, str)}


def _dict(value: Any) -> dict[str, Any]:
    return _mapping(value, "mapping") if isinstance(value, Mapping) else {}


def _list(value: Any, label: str) -> list[Any]:
    if not isinstance(value, list):
        raise ValueError(f"DSH {label} must be an array")
    return value


def _required_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError(f"DSH {label} must be a non-empty string")
    return value


def _optional_string(value: Any) -> str | None:
    return value if isinstance(value, str) and value else None


def _revision(value: Any) -> int:
    return _nonnegative_int(value, "revision")


def _nonnegative_int(value: Any, label: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"DSH {label} must be a non-negative integer")
    return value


def _boolean(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if not isinstance(value, bool):
        raise ValueError("DSH boolean field is invalid")
    return value
